MacroPad – GUI Macro Configuration Tool  
========================================

Description:
------------
This is a standalone Windows application for configuring a 3x3 macro pad interface. It allows you to set up macros, analyze logs via the built-in Rust log analyzer, and optionally interact with firmware for the ATmega32U4 microcontroller.

This tool was built using Python and compiled into an .exe using PyInstaller. It includes:
- The main MacroPad GUI
- The `log_analyzer.exe` for parsing macro logs
- Supporting folders for configuration and firmware reference

Instructions:
-------------
1. Extract the contents of the .zip file to any location.
2. Pick either App or App console. These are shortcuts that can be placed on desktop (App console has console, App w/o console).
3. Run `MacroPadApp.exe` or 'MacroPadApp_console.exe (the standalone GUI application) or one of the shortcuts.
4. Ensure the `log_analyzer/` folder is in the same directory as the `.exe` — it's required for log parsing to function.
5. Refer to the `firmware/` folder for source code if you're flashing custom firmware (instructions not included here).

Folder Structure:
-----------------
MacroPad_dis/
├── MacroPadApp.exe           <- Main executable
├── log_analyzer/
│   └── log_analyzer.exe      <- Rust-based log analyzer
├── firmware/
│   └── [source files]        <- C++ code for ATmega32U4 firmware
└── README.txt                <- This file

Customizing Key Bindings:
-------------------------
1. Launch the GUI by running `MacroPadApp.exe`, 'MacroPadApp_console.exe' or a shortcut equivalent.
2. You'll see a 3x3 grid of buttons representing the macro pad layout.
3. Click any button to configure its macro action.
4. Enter a sequence of key commands and optional delays. Commands are comma-separated.
   Examples:
   - `ctrl+c` → Presses Ctrl+C
   - `ctrl+v` → Presses Ctrl+V
   - `delay 500` → Waits 500 milliseconds
   - `ctrl+c, delay 300, ctrl+v` → Copies, waits 300ms, pastes

Sample Macros:
--------------
- Copy selected text:
  ctrl+c

- Paste after a short delay:
  delay 200, ctrl+v

- Quick save and close:
  ctrl+s, delay 100, alt+f4

- Open Task Manager:
  ctrl+shift+esc

- Launch Run dialog, type "notepad", and press Enter:
  win+r, delay 500, n, o, t, e, p, a, d, enter

System Requirements:
--------------------
- Windows 10 or later
- No Python installation required
- Admin privileges may be needed to flash firmware (optional)

Notes:
------
- This app does not phone home, collect analytics, or update itself.
- If the GUI fails to start, check that all files/folders remain in their original layout.
- If antivirus flags the .exe, it's a false positive from PyInstaller packaging.

Author:
-------
Caleb Thomas 
https://github.com/Johniecache/MacroPad

License:
--------
MIT License (see GitHub repo for full license text)
