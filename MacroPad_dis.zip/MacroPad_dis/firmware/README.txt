Firmware - GUI Macro firmware flashing
========================================

Description:
------------
These files are used for flashing to the Ardiuno ATmega32U4 pro mirco. Anything else has not been tested and may crash or have unexpected results.

Instructions:
-------------
Use 'MacroPad_Firmware.ino.hex' if flashing via USB bootloader (ie QMK Toolbox, Arduino).
Use 'MacroPad_Firmware.with_bootloader.ino.hex' if flashing to a raw chip or recovering a bricked board using ISP (ie USBasp).

1. Open Arduino IDE
2. File > Open > 'MacroPad_Firmware.ino.hex'
3. Choose device in drop down
4. Ensure correct COM# is selected
5. Verify file integrity
6. Upload to device

NOTE: 
 - I have untested the 'with_bootloader.ino.hex' file so unexpected results could occur.
 - I have untested an other application that can flash to ATmega32U4 so do at your own risk.